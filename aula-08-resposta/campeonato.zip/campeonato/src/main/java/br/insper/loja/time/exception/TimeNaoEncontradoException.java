package br.insper.loja.time.exception;

public class TimeNaoEncontradoException extends RuntimeException {

    public TimeNaoEncontradoException(String mensagem) {
        super(mensagem);
    }

}
