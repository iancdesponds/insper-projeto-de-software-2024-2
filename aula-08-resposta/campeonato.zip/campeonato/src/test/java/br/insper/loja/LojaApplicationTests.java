package br.insper.loja;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LojaApplicationTests {

	@Test
	void contextLoads() {
	}

}
